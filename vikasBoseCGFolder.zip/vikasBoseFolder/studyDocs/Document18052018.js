VLLS - 2 spoon 
colagte - 2 muttor createElement
Generate the count till 100
var a = document.querySelector('div');    
for(var i =1; i<=100; i++) {
  a.textContent += i +'\n';
}
Generate a random number between 1 and 100
  a.textContent = Math.floor(Math.rendom(i) * 100);
  
Record the turn number the player is on. Start it on 1
var count = 1;
var b = document.querySelector('button');
b.onclick = function() {
  console.log(count);
  count = count + 1;
}
Provide the player with a way to guess what the number is
	