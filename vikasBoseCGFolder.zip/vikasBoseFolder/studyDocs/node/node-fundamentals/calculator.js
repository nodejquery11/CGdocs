class Calculator{
    add(a,b){
        return a + b;
    }
    multiply(a,b){
        return a * b;
    }
}
//To export a module
module.exports = Calculator;