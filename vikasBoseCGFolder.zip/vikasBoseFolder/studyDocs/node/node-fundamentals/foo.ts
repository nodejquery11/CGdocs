var str:string = 'Using TypeScript we can JS Strongly Typed';

var demo = ()=>'Typescript converts ES2015 to ES5';

class Employee{}
class Manager extends Employee {}