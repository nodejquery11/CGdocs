const os = require('os');
const path = require('path');

console.log(os.hostname());
console.log(path.join(__dirname,'index.html'));