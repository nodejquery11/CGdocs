/* 
class & function consturctor
Event Emitter
How to prevent dev dependancy in production server
How to install your application in production server using git or jenking
AWS and what is AWS SDK (how to authorized the application using AWS)
why and what is the use router in node js? can we render our page without using router.
How to create module in node js and structure.
why & what is the user of module.exports in node js.
Promise in JS and what is the difference b/w promise & callback? Syntax
Buffer and where do we use buffer?
Pipping in node js and what is stack in node and how pipping is use full in stack?
Have you use ES6 in node js and why ES6 more usefull?
How to implement ES6 with node js ?
what is process & child-process
REPL
Event listner & Event loop & Event Handler



*/
/*
SAP ABAP OOPS
SAP ABAP HANA
Teradata Developer
Hadoop Developer(Hive or Spark)
Linux + Scripting Engineer
Cloud & Edge Architect  - AWS, Azure
Python
NoSQL, MongoDB
Spring framework
Drupal
VC++ Developer
Performance Test Engineer
SAP ABAP OOPs BOPF
SAP BASIS-Azure
Python / Perl Automation Testing

*/

Event module
// EventEmitter is the method, which create the custom events using node core modules
var event = require('events');

//jquery
element.on('click', function(){ ... }); [element will be fire the click even the we will listen the event using callback function]

//Event emitter
// EventEmitter is the constructor of events module so we call this using new keyword
var myEmitter = new event.EventEmitter();
myEmitter.on('someEvent', function(msg) { // calling the event `someEvent`
	console.log(msg);
});

myEmitter.emit('someEvent', 'hello vikas'); // create the event

// second ex
var util = require('util'); // [allow to inhrite the different module object or core object in node ]
var person = function(name) {
	this.name = name;
};

util.inherits(person, event.EventEmiter); // so person object has ability to inherit the eventEmitter feature

var vikas = new person('vikas');
var siva = new person('siva');
var karthik = new person('karthik');
var people = [vikas, siva, karthik];

people.foreach(function(person){
	 person.on('speak', function(msg) {
	 	  console.log(person.name+': said '+msg);
	 });
});
vikas.emit('speak', 'hello vikas');

Event Listener
//An event listener is a procedure or function in a computer program that waits for an event to occur; that event may be a user clicking or moving the mouse, pressing a key on the keyboard, or an internal timer or interrupt. The listener is in effect a loop that is programmed to react to an input or signa
document.addEventListener('click', myfunction, false);

Event bubbiling
// parent > child > child [let if you create an event on parent then it will execute only once but if you child is dependent on the parent then once you ganerate the event, it will call it self and then parent. So it will buuble the event on an on ]
// how to prevent the event bubbling 
event.target // it will target the event ganerator and then listen the same event only
this // is the “current” element, the one that has a currently running handler on it.
	
/* What is the difference between app.use() & router.use() */
app.use() object use for mounting a middlewear at a path. mounts middleware for all routes of the app (or those matching the routes specified if you use app.use('/ANYROUTESHERE', yourMiddleware());)
router.use(); mounts middleware for the routes served by the specific router,

app.js

var express = require('express');
var router = express.Router();
app.use(router);
app.use('/user', userRouter);

userRouter.js
var express = require('express');
var router = express.Router();

router.get('/', function(req, res, next) {
	 console.log(req, res);
	next();
});
router.get('/:id', function(req, res, next) {
	 console.log(req, res);
	next();
});
module.exports = router;

