# IMP ponits or questions
1) What [defination & benifits]
2) Why [utility]
3) How [implemention]
4) Where 

# Project Related IMP points:

Building the line, they using regression js and calculation of it. Calculation is also based on the methods[line #95] like linear/ Power etc. And it will add in your data object and call as `Y2`.
var result = null;
result = regression(regressiontype, temp_data, 1);
 _.each(data, function(elm, i) {
     elm.Y2 = result.points[i][1]; // [0]=x,[1]=ax+b
});

Note: In both case the axis `X` common.

Issues:
1. Do not know about the calculation, once click or select the circle, how much deflection happen?
2. JavaScript limit [id is common or duplicated multiple graphs]. Impliment only work on single graph ploted in sheet.
3. 


# D3 js learning guide
To access the DVD practice files and figure samples that accompany this book, visit https://swft.exavault.com and log in using the following case-sensitive credentials: 
USER: d3kin 
PASSWORD: kappa406 


# ************************ Node Js **************************
$ IMP notes & queries:
? Howmany types of API
1. Public API & 2. Embedder API

# AsyncHooks
Async hook API will allow the develop to track the asynchronous request and handle through their complete life-cycle [new feature in node and version 8]. In other words, this module provide the registered callbacks tracking the lifetime of Async resource created in Node Js application.
Benifits: 
1.Now developer can track all the Async request by user.
2.It also help the emits events, which has all information about the life of all handle objecs.
In Async_hooks has four major functions 
    1. createHook [create a new Async hook and init, before, after, distory and promiseResolve functions are optional]
    2. executionAsyncId
    3. triggerAsyncId
    4. AsyncResource

$ Step01: const async_hooks = require('async_hooks');
  step02: const asyncHook = async_hooks.createHook(callback); [callbacks to register and return the asyncHook instance. It may use init(), before(), after() and destroy()]
  step03: asyncHook.enable() [to enable the Async hook]
  step04: asyncHook.disable() [to disable the callback instance]

Note: Basic use of this module to make track, howmany time async process call like howmany time your connection string execute

const async_hook = require('async_hooks');
async_hook.creatHook({
   init(asyncId, type, triggerAsyncId) {
       const eid = async_hook.executionAsyncId();
       console.log(
         1, `${type}(${asyncId}): trigger: ${triggerAsyncId} execution: ${eid}\n`
       );
   }
});
require('http').createServer((conn) => {}).listen(3000);

# Buffer:
It is kind of mechnizam where we block or create chunk of data size and send into the server instead directly send all the data into the server. It also create the memory allocation outside of v8 heap. Buffer class is used because JS is not good to handle the binary data.
Syntax: 
  let buffer = require('buffer') or let buffer = require('buffer').Buffer [Here `Buffer` is the main function of buffer module];
  OR
  let buf = new Buffer(<size_of_buffer>);
  > Note: differnce b/w both syntax is fist syntax containt specific methods, however second one only engage the methods.
  > poolSize: this is the number of bytes to pre-allocated internal buffer use for pooling. Default value is 8192 Bytes and this default value can be change. If you manually pass the value into the buffer then it may update the lenght of poolSize.
  > buffer.alloc(size): it will allocated the memory to buffer with zero-filled. And if you do not pass the `size` then it will throw an error. if you want the buffer filled with some other values then u must use buffer.alloc(size, value); And instead of integer, if u pass char then it will take ascii value of char and fill the buffer
  > buffer.allocUnsafe(size): create uninitilized buffer and it is faster then `alloc` method but not secure. Because it might contain the previous or old data in it. To overwrite it, we need to execute the function call fill() & write().
  > ?How to create or insert array into buffer
    buffer.from([values]) or new Buffer([values]);
  > ?How to write into buffer
    in the first method, single fnction can do both read and writing but if u use the buffer class then u must pass the argument directly from buffer class. however, buffer.write will display the number of charectors.
    Ex, bufWrite = buffer.from("hello world", "utf8"); [it will return the binary code with consume the buffer memory]
        buffer = new Buffer("Hello World", "utf8") bufWrite = buffer.write(); [it will return the lenght of string]
        bff.toString() will print the initial value for both pattern.
  > If you pass the buffer value from buffer.from then it will reserve the memory allocation of buffer.
const buf = buffer.from('This vikas bose', "utf8");
const buf1 = buffer.from('Hello!', "utf8");
const buf2 = buffer.from('World!', "utf8");
buf.compare(buf1); // false
buf.concat([buf1, buf2], totallength); //This vikas bose Hello! World
buffer.isBuffer(buf); // true
buffer.isEncoding(buf); // true
buffer.poolSize; // default: 8192
buffer.copy(target, start, destination, end);
buf.equal(buf2); // false because buf !== buf2 no value
buf.fill('h'); // it will replace the `buffer` value `h`
buf.includes('this'); // searching the agr into buffer and this is case sensitive
buf.indexOf('this'); // it will return the index number
buf.values(); // to return the value of buffer string array r object

# Type Scrip: 
This script is identifing the type of variable, if the variable type will not match with the exact argument then it throws an error and an error as follows
`main.ts(1,5): error TS2322: Type '"Hello World"' is not assignable to type 'number'.`
var message:number = "vikas bose"
Benifits:
    1.strong type checking
    2.compile time error check and success the JS in full enterprise edition
    3.JavaScript is typeScript, it means that JS might change into *.ts and complied in typeScript.
    4.Compilation Error: as JS is interpretor lanaguage but using TypeScript, you can compile the code and generate the compiler error with sort of compile error discription.
    5.component of TS: langauge -> TS compiler ->langauge service. once it done, it creates declaration file with extension *.d.ts and it will support all the library.
Decalration variable in TS:
  var <var_name>:<data_type> = <var_value>;
TS variable scope: there are three kind of var scope
1.Global []
2.Class
3.local

# ES6: ES6 will work once you install the babel in your application. 
Triple dot (spread operator): it will sparated the multiple passing argument using some mechnizam. Passing argument must be an immutable array or object.
Example: let a = [1, 2, 3];
let fun = function(...a) {
  console.log(arg); //1, 2, 3
}
#In simple JS instead of triple dot, we use arguments(default key). It also take the all argument, which pass on the calling function.
#there are multiple kind of parameters 
    1. optional parameter [if parameter will not required then we mentioned parameter using `?:<dataType>`]
      var a = function(arg:string, arg1: number, ard2?:string) { ....... statement}
    2. Rest parameter [if we pass the miltiple argument or array or object into function then we use spread operate]
    3. Default parameter [if you want to set any default value to the argument, even after if user run the code but not provide the parameter]
      var a = function(arg:string, arg1: number, ard2:string=default_val) { ....... statement}

# callback
It is a kind of methology to reduce burdon of client & server. it is the async process which will execution continues with the help of callback. 
var loadScript = function(src, cb) {
  var script = document.createElement('script');
  script.src = src;
      script.onload = function(d) {
         cb(d);
      }
  document.head.append(script);
};
loadScript('/js/main.js', function(d){
   console.log(d);
});

# ***********************
var Greeting = /** @class */ (function () { //*.js
    function Greeting() {
    }
    Greeting.prototype.greet = function () {
        console.log("Hello World!!!");
    };
    return Greeting;
}());
var obj = new Greeting();
obj.greet();

class Greeting { //*.ts
   greet():void { 
      console.log("Hello World!!!") 
   } 
} 
var obj = new Greeting(); 
obj.greet();

# ***********************

    


# cluster
?what is cluster
Node Js 
# Process Module:
> node Js only use single process
$ process.argv [arguments are 1. node js path, 2. a path where is your file]
$ node index.js --param [ then 3rd argment value will be --param and if you pass something after it, it will add in an array]
$ process.stdout & process.stderr
process.stdout is equal to console.log() [process.stdout.write(msg + '\n')]

Note: setTimeout(callback, delay) // it will be run once and print the statement and exit
setInterval(callback, delay) // it will be run continiously whenever u did not break it. If you want to break the process using simple JS then clearInterval(callback) or using node js process.exit();

# child process module:
This module basically use for not to interept the main process and run another process in beckground then we can use child process. For ex, if we have any process written in *.bat and need to run in background then
1.exec
var exec = require('child_process').exec;
exec('command file_name', function (err, stdout, stderr) {
    console.log('Hello', stdout);
}); // this will work ascat command 
2.spawn

# Stream Module
> 

# ************************ JavaScript **************************

=> undefined [if you declare the variable but not assgine the value then console will throw an error `undefined`]
Ex. var vName;
    console.log(vName);
=> re-declare [if you declare the same name of variable the the variable not loss thevalue assign. But in the second time if you assign the value then you might loss your previous assign value]
Ex. var cName = "vikas";
    var cName;

$ if you want to increment the variable using map function
var incr_val = 0; //initilized first
arr.map(function(d, incr_val) {
   return {
      "data": d,
      "i": i+1
   }
});

# Chaning in JS [https://schier.co/blog/2013/11/14/method-chaining-in-javascript.html]
// define the class
var fullName = function () {}

// define prototype
fullName.prototype.setName = function (name) {
  this.name = name;
  return this;
}
fullName.prototype.setSurname = function (lastName) {
  this.surname = lastName;
  return this;
}
fullName.prototype.save = function() {
  console.log (this.name +'=='+ this.surname);
}

// create an object of empty class
var x = new fullName();
x.setName('vikas')
  .setSurname('Bose')
  .save();

IMP note: if you try to write an normal prototype function and use chain then it will return an error into second function that `uncought error: property not defined or undefined`. To resolve this issue we need to send or return the output to the main object. So every prototype musy send the return the value.

# Hoisting in JS
This the concept of variable declaration but it might be applicable for functions as well. So `hoisting` is the methology to declare the variable, in earlier JS developer assign the value to the variable but they define the variable later and JS did not send or throw an error but it log into the browser logs. It become the cause to make slow JS. Because if you assign the value to the variable but before not to define the variable then it will give you the `undefined` error. So prevent this issue, in Advance Js we have added one key or statement `use strict`. So it will compile your `hoisting` issue to procced into browser.
`strict` definition suggested that variable & function declararions must be moved to top of your code 
For example:

$ variable hoisting
(function() {
  var x = 1;
  console.log(x, y, z);
  var y = 2;
  var z = 3;
})();
output: 1, undefined, undefiend

$ function hoisting
x();
var x = function() {
   console.log(2 * 3);
}
output: typeError: x is not a function on line #. Usually function reserve the memory so later it can be use as reference. So that we must decalre or define the function and call it.

Note: let suppose if you print the variable but not declare or define it then it will throw an `ReferenceError` like
(function() {
  var i = 1;
  console.log(i, j);
})();
Output: so j will give the reference error.

? why do we prevent the hoisting
Because JS is intepretor language. So that it will compile top to bottom. If you decalre the variable and try to print the variable value before the assign the value then it will give the variable is undefined and later process the execution and print the variable value as well. `So it has happen because once it will not find the variable then compiler re-run the code and second time it will print it.`
var c;
console.log(c); //undefiend
c = 3; // print the 3
function hoisting is also similar to the variable hoisting. In this we declear the function but defination will be later 


# closure in JS

# String function in JS
a. str.charAt(indexNumber);           [it will return char of the string basis on the passing index]
b. str.charCodeAt(indexNumber);       [it will return the ascii code basis of index value]
c. str.concat(str2);                  [join two or more strings]
d. str.fromCharCode(indexNumber);     [it will return the char value basis of ascii code]
e. str.includes(value);               [it will return the boolean value if the value exist in the string]
f. str.indexOf();                     [if it will return the posivie value then searching value is exist or else not]
g. str.match(str);                    [it will return you exeact maching string, it is also follow the case sensitivness]
h. str.repeat(val);                   [it will create the copy of parent string basis of passing argment]
i. str.replace(replaceString);        [it will replace the current value using pass arg]
j. str.search(val);                   [it will return the index value, where the string is]
k. str.split();                       [to split the string either obj or array]
l. str.slice(startIndex, sliceIndex); [it will return the string basis of both argument]
m. str.toLowerCase() & str.toUpperCase & str.toString()
n. str.valueOf();                     [to return the exeact value]

# Funcation pattern
1. Normal function [it must be use as the function key word with function name]
   function fun_name() {....}
2. Anonymous function [it is similar to normal function but only change is function must assign to variable]
   var fun_name = function() {....}
3. Self-invoking function [function execute it self, function calling is not required in it]
   var fun_name = (function(){ ... })();


Note: function are also objects




# Recursive function


BTST : Buy Today Sell Tomorrow
Mergin Buy/ Sell/ Plus for interaday only (in interaday we can buy or sell multiple of 40)
# If you want to buy any shares then open price and low price must be equal
# If you want sel lthe share then open price and high price must be equal

TypeScript - 14/May/18 :  PSN _TR-1_Door No-556_5th Floor , Bangalore [Cancel]
React Js - 14/may/18
Jenkins Overview - 16/may/18
Node Js - 22/may/18

# Programming links
https://stackoverflow.com/questions/10359907/array-sum-and-average 



# React JS
Two imp concept in React Js
1. virtual dome 
2. diff algorithem
One of basic benefit is SPA (single page application)
Render views ultra-quickly
> Custom component or tag in html
  Polymer / polithin 

\\DIN80011918\react
https://babeljs.io/repl/#?babili=true&browsers=&build=&builtIns=false&code_lz=DwCwjABAlgJgvAIgO4FMA2BjA9gWxQgPgCgIJgAHCHAT1jgHIwAmAZnoIGEBDcgcxRxQAdlGAB6csXHgCQA&debug=false&forceAllTransforms=false&shippedProposals=false&circleciRepo=&evaluate=true&fileSize=true&lineWrap=true&presets=es2015%2Creact%2Cstage-2%2Cbabili&prettier=true&targets=&version=6.26.0&envVersion=




