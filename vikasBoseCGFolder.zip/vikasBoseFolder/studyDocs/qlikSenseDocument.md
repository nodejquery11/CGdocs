# Create qlik sense Extension

$ Main files:
    wbfolder.wbl [initial file]
    com-qliktech-d3App.qext; [extension mata data file]
    com-qliktech-d3App.js; [main js file]
    d3.v3.min.js [library]
    # *.css, image files,

$ Skeleton of main file
define(["qlik", "Jquery", "./d3.min"]
  function (qlik, $, d3) {
    'use strict';
    return {
       definition: {} //define the items
       support: {
         snapshot: true,
         export: true,
         exportData: true1
       } // taking print or screen shot
       paint: function ($element, layout) {} //write business logic
    } //end return 
  } //end function
);

$element : jQuery wrapper containing the HTML element where the visualization should be rendered.
layout : Data and properties for the visualization.


appearancePanel: {              /*Appearance Panel*/
    uses: "settings",
    items: {
        MyStringProp: {
            ref: "myDynamicOutput",
            type: "string",
            label: "Hello World Text"
        }
    }
}


# Note: Export is not happen in Qlik sense.
$. minor code changes
    1. add the qlik library in `define` array
    2. add the qlik object into the main function
    3. add `support` object instead of `snapshot` and put the object properties like snapshot, export and exportData as true.
    support: {
      snapshot: true,
      export: true,
      exportData : true
    }
$. Important file
    wbfolder.wbl: initial file and we need to mentioned the file name with their extention, so it create the same into cloud as well.
    
    *.qext: extention file for declaring the visulization, version, icon, preview etc. It is important to file for qlik, it tells to qlik that this visulization is exist in the template folder.
    
    main file name must be like `com-qliktech-<customFilename>`.js or .qext.




  

