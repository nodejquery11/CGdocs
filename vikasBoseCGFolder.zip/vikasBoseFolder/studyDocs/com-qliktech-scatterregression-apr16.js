define(["qlik", "jquery", "underscore", "./dimple.latest", "./d3.min", "./regression"],
function(qlik, $, _, dimple, d3) {
  'use strict';
  return {
    initialProperties : {
      version: 1.0,
      qHyperCubeDef : {
        qDimensions : [],
        qMeasures : [],
        qOutliers : [],
        qInitialDataFetch : [{
          qWidth : 3,
          qHeight : 500
        }]
      }
    },
    //property panel
    definition: {
      type: "items",
      component: "accordion",
      items: {
        dimensions: {
          uses: "dimensions",
          min: 1,
          max: 1
        },
        measures: {
          uses: "measures",
          min: 2,
          max: 2
        },
        sorting: {
          uses: "sorting"
        },
		settings: {
		  uses: "settings",
		    items: {
			  colorPanel:{
			    type:"items",
				label:"Graph Settings",
				items: {
					item0: {
					type: "string",
					component: "dropdown",
					label: "Regression type",
					ref: "nodeColor.regressionType",
					options: [
							{value: 'linear', label: 'Linear'},
							{value: 'exponential', label: 'Exponential'},
							{value: 'logarithmic', label: 'Logarithmic'},
							{value: 'power', label: 'Power'},
						    {value: 'polynomial', label: 'Polynomial'}
							],
					defaultValue: 'power'
					},
				  item1: {
					ref: "nodeColor.keyword1",
					label: "Keyword 1 (3 characters)",
					type: "string",
					defaultValue: "PAC"
					},
				  item2: {
					ref: "nodeColor.value1",
					label: "Color1",
					type: "string",
					defaultValue: "#01AE9D"
					},
				  item3: {
					ref: "nodeColor.value2",
					label: "Color2",
					type: "string",
					defaultValue: "#EEF9F8"
					},
				  item4: {
					ref: "nodeColor.keyword2",
					label: "Keyword 2 (3 characters)",
					type: "string",
					defaultValue: "OUT"
					},
 				  item5: {
					ref: "nodeColor.value3",
					label: "Color3",
					type: "string",
					defaultValue: "#FF0000"
					},
				  item6:{
					ref:"nodeColor.transSwitch",
					component:"switch",
					type:"boolean",
					label:"Show Equation",
					options: [
							{
								value: true,
								label: "On"
							},
							{
								value: false,
								label: "Off"
							}
							],
					defaultValue:true
				   }
				}
			  }
           }
		}
      }
    },
    support: {
      snapshot: true,
      export: true,
      exportData : true
    },
    paint : function($element, layout) {
      var self = this;
      var dimensions = layout.qHyperCube.qDimensionInfo;
      var measures = layout.qHyperCube.qMeasureInfo;
      var matrix = layout.qHyperCube.qDataPages[0].qMatrix;
      var width = $element.width();
      var height = $element.height();

      var user_prop = layout.nodeColor;
      var colorself = user_prop.value1;
      var colorothers = user_prop.value2;
      var coloroutlier = user_prop.value3;

      var PACothers = user_prop.keyword1;
      var PACoutlier = user_prop.keyword2;
      var regressiontype = user_prop.regressionType;

      if(matrix) {
        //////////////
        var id = "chartcontainer_" + layout.qInfo.qId;
        if(document.getElementById(id)) 
          $("#"+id).empty();
        else
          $element.append($('<div />;').attr("id", id).width(width).height(height));
        
        var svg = dimple.newSvg("#"+id, width, height);
        var data = matrix.map(function(d) {
             var DIM = d[0].qText;
             var X = d[1].qNum;
             var Y = d[2].qNum;
             if(isNaN(X)) X = 0;
             if(isNaN(Y)) Y = 0;
             return {
                "DIM": DIM,
                "X": X,
                "Y": Y
              };
           });
         var data1 = matrix.filter(function(d) {
               return d[0].qText.split("-")[1] !== "Actual Outlier";
           }).map(function(d){
                 var DIM = d[0].qText;
                 var X = d[1].qNum;
                 var Y = d[2].qNum;
                 if(isNaN(X)) X = 0;
                 if(isNaN(Y)) Y = 0;
                 return {
                    "DIM1": DIM,
                    "X1": X,
                    "Y1": Y
                  };
           });
         var data2 = matrix.filter(function(d) {
               return d[0].qText.split("-")[1] === "Actual Outlier";
           }).map(function(d){
                 var DIM = d[0].qText;
                 var X = d[1].qNum;
                 var Y = d[2].qNum;
                 if(isNaN(X)) X = 0;
                 if(isNaN(Y)) Y = 0;
                 return {
                    "DIM": DIM,
                    "X": X,
                    "Y": Y
                  };
          });
         var temp_data1 = _.map(data1, function(d) {
              return [d.X1, d.Y1];
         });
     
         var result = null;
		 result = regression(regressiontype, temp_data1, 1);
         _.each(data1, function(elm, i) {
             elm.Y2 = result.points[i][1]  // [0]=x,[1]=ax+b
         });
         
         var y_max = _.max(data1, function(d) { return d.Y1; });
         y_max = y_max.Y1;
         var y2_max = _.max(data1, function(d) { return d.Y2; });
         y2_max = y2_max.Y2;
        
         var fd = data1.concat(data2);

         var chart = new dimple.chart(svg, data1);
         chart.setBounds(60, 30, width-80, height-80);

         var x1 = chart.addMeasureAxis("x", "X1");
          console.log(x1);
            x1.tickFormat = ".1f";
            x1.ticks = 10;
            if( !measures[1].qIsAutoFormat && measures[1].qNumFormat.qFmt.length > 0 )
            x1.tickFormat = measures[1].qNumFormat.qFmt;

         var y1 = chart.addMeasureAxis("y", "Y1");
            y1.tickFormat = ".1f";
            y1.ticks = 10;
            if( !measures[0].qIsAutoFormat && measures[0].qNumFormat.qFmt.length > 0 )
            y1.tickFormat = measures[0].qNumFormat.qFmt;
            y1.overrideMin = 0;
            y1.overrideMax = Math.max(y_max, y2_max); 
          
         var y2 = chart.addMeasureAxis("y", "Y2");
            y2.hidden = true;
            y2.tickFormat = y1.tickFormat;
            y2.overrideMin = y1.overrideMin;
            y2.overrideMax = y1.overrideMax;
          
        $.each(data1, function(d) {  
			if (data1[d].DIM1.substr(0, 3) != PACothers ) {
				chart.assignColor(data1[d].DIM1, colorself, "grey", 1);
			}
			else {
				chart.assignColor(data1[d].DIM1, colorothers, "grey", 1);
			}
		});

        var s2 = chart.addSeries(["DIM1"], dimple.plot.line, [x1, y2]);
        var s = chart.addSeries(["DIM1"], dimple.plot.bubble, [x1, y1]);

// ################# Actual Outlier
        var temp_data = _.map(data2, function(d) {
              return [d.X, d.Y];
         });
     
         var result = null;
		 result = regression(regressiontype, temp_data, 1);
         _.each(data2, function(elm, i) {
             elm.Y2 = result.points[i][1] // [0]=x,[1]=ax+b
         });        
        var x_max = _.max(data, function(d) { return d.X; });
        x_max = x_max.X;
        
        var chart1 = new dimple.chart(svg, data2);
        chart1.setBounds(60, 30, width-80, height-80);
        
        var x = chart1.addMeasureAxis("x", "X");
        x.tickFormat = ".1f";
        x.ticks = 10;
        x.hidden = true;
        x.overrideMax = x_max;
        if( !measures[1].qIsAutoFormat && measures[1].qNumFormat.qFmt.length > 0 )
        x.tickFormat = measures[1].qNumFormat.qFmt;

        var y = chart1.addMeasureAxis("y", "Y");
        y.tickFormat = ".1f";
        y.ticks = 10;
        y.hidden = true;
        if( !measures[0].qIsAutoFormat && measures[0].qNumFormat.qFmt.length > 0 )
        y.tickFormat = measures[0].qNumFormat.qFmt;
        y.overrideMin = 0;
        y.overrideMax = Math.max(y_max, y2_max);
        
        $.each(data2, function(d) {
			if (data2[d].DIM.split("-")[1] === "Actual Outlier" ) {
				chart1.assignColor(data2[d].DIM, coloroutlier, "red", 1);
			}
		});
        var s1 = chart1.addSeries(["DIM"], dimple.plot.bubble, [x, y]);
        chart1.draw(800);        

        if( user_prop.transSwitch ) {
			x1.title = measures[0].qFallbackTitle + " [R\xB2 = " + result.r2 + "] "+ "[" + result.string + "]";
		} else {
			x1.title = measures[0].qFallbackTitle;
		}
		y1.title = measures[1].qFallbackTitle;
        chart.draw();
        
        /*var filterValues = dimple.getUniqueValues(data, "DIM");
        $("circle").click(function() {
            var newLinefun = jqueryNewLine(layout, user_prop, _, measures, data, this.id);
            chart.data = dimple.filterData(newLinefun, "DIM", filterValues);
            chart.draw(800);
        });*/
      }
    }
  };
});

var jqueryNewLine = function (layout, user_prop, _, measures, preData, clkCircleId) {
   var regressiontype = user_prop.regressionType;
   var checkData = clkCircleId.split("-");
   var updateArr = [];
   preData.map(function(d) {
         var DIM = d["DIM"];
         var X = d["X"];
         var Y = d["Y"];
         if(isNaN(X)) X = 0;
         if(isNaN(Y)) Y = 0;
         updateArr.push({
           "DIM": DIM,
           "X": X,
           "Y": Y
         });
   });
   var temp_data = _.map(updateArr, function(d) {
      return [d.X, d.Y];
   });
 
   var result = null;
   result = regression(regressiontype, temp_data, 1);
   _.each(updateArr, function(elm, i) {
       var xR = Math.floor((Math.random() * 5) + 1);
       elm.Y2 = ((result.points[i][1] * xR) > measures[1].qMin && (result.points[i][1] * xR) < measures[1].qMax ) ? (result.points[i][1] * xR) : result.points[i][1]; // [0]=x,[1]=ax+b
   });
  return updateArr;
}