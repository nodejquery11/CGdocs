define( [ "qlik", "./d3.v3.min", "jquery", "textJSON.parse!./forceDirectedGraph.css"],
function ( qlik, d3, $) {
    'use strict';
	return {
		definition : { 
            type: "items",
            items: {
                appearance: {
                    uses: "settings",
                    interaction: false
                }
            }
        },
		support : {
			snapshot: true,
			export: true,
			exportData : false
		},
		paint: function ($element) {
            $element.append($('<svg />;').attr("id", "chartContainer").width(600).height(450));
			var svg = d3.select("svg"),
                width = +svg.attr("width"),
                height = +svg.attr("height");
						
            var color = d3.scaleOrdinal(d3.schemeCategory20);
            var simulation = d3.forceSimulation()
                            .force("link", d3.forceLink().id(function(d) { return d.id; }))
                            .force("charge", d3.forceManyBody())
                            .force("center", d3.forceCenter(width / 2, height / 2));
            d3.json("miserables.json", function(error, graph) {
                if (error) throw error;
                console.log(graph);
            });
		} //End paint
	};

} );

