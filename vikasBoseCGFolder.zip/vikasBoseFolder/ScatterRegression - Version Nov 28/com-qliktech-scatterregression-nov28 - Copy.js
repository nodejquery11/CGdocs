define(["jquery", "underscore", "./dimple.latest", "./d3.min", "./regression"],
function($, _, dimple, d3) {
  'use strict';
  return {
    initialProperties : {
      version: 1.0,
      qHyperCubeDef : {
        qDimensions : [],
        qMeasures : [],
        qInitialDataFetch : [{
          qWidth : 3,
          qHeight : 500
        }]
      }
    },
    //property panel
    definition: {
      type: "items",
      component: "accordion",
      items: {
        dimensions: {
          uses: "dimensions",
          min: 1,
          max: 1
        },
        measures: {
          uses: "measures",
          min: 2,
          max: 2
        },
        sorting: {
          uses: "sorting"
        },
		settings: {
		  uses: "settings",
		    items: {
			  colorPanel:{
			    type:"items",
				label:"Graph Settings",
				items: {
					item0: {
					type: "string",
					component: "dropdown",
					label: "Regression type",
					ref: "nodeColor.regressionType",
					options: [
							{value: 'linear', label: 'Linear'},
							{value: 'exponential', label: 'Exponential'},
							{value: 'logarithmic', label: 'Logarithmic'},
							{value: 'power', label: 'Power'},
						  {value: 'polynomial', label: 'Polynomial'}
							],
					defaultValue: 'power'
					},
				  item1: {
					ref: "nodeColor.keyword1",
					label: "Keyword 1 (3 characters)",
					type: "string",
					defaultValue: "PAC"
					},
				  item2: {
					ref: "nodeColor.value1",
					label: "Color1",
					type: "string",
					defaultValue: "#01AE9D"
					},
				  item3: {
					ref: "nodeColor.value2",
					label: "Color2",
					type: "string",
					defaultValue: "#EEF9F8"
					},
				  item4: {
					ref: "nodeColor.keyword2",
					label: "Keyword 2 (3 characters)",
					type: "string",
					defaultValue: "OUT"
					},
 				  item5: {
					ref: "nodeColor.value3",
					label: "Color3",
					type: "string",
					defaultValue: "#FF0000"
					},
				  item6:{
					ref:"nodeColor.transSwitch",
					component:"switch",
					type:"boolean",
					label:"Show Equation",
					options: [
							{
								value: true,
								label: "On"
							},
							{
								value: false,
								label: "Off"
							}
							],
					defaultValue:true
				   }
				}
			  }
			}
		}
      }
    },
    snapshot: {
      canTakeSnapshot: true
    },
    paint : function($element, layout) {
  var self = this;
  var dimensions = layout.qHyperCube.qDimensionInfo;
  var measures = layout.qHyperCube.qMeasureInfo;
  var matrix = layout.qHyperCube.qDataPages[0].qMatrix;
  var width = $element.width();
  var height = $element.height();

  var user_prop = layout.nodeColor;
  var colorself = user_prop.value1;
  var colorothers = user_prop.value2;
  var coloroutlier = user_prop.value3;

  var PACothers = user_prop.keyword1;
  var PACoutlier = user_prop.keyword2;

  var regressiontype = user_prop.regressionType;
 
      if(matrix) {
        //////////////
        var id = "chartcontainer_" + layout.qInfo.qId;
        if(document.getElementById(id))
          $("#"+id).empty();
        else
          $element.append($('<div />;').attr("id", id).width(width).height(height));

        var data = matrix.map(function(d) {
					 var DIM = d[0].qText;
                     var X = d[1].qNum;
                     var Y = d[2].qNum;
                     if(isNaN(X)) X = 0;
                     if(isNaN(Y)) Y = 0;
                     return {
					   "DIM": DIM,
                       "X": X,
                       "Y": Y
                     }
        });
        console.log('Old => ', data.X, data.Y);
        var temp_data = _.map(data, function(d) {
          return [d.X, d.Y];
        });
        var result = null;
		result = regression(regressiontype, temp_data, 1);
        _.each(data, function(elm, i) {
         elm.Y2 = result.points[i][1]; // [0]=x,[1]=ax+b
        });

        var y_max = _.max(data, function(d) { return d.Y; });
        y_max = y_max.Y;
        var y2_max = _.max(data, function(d) { return d.Y2; });
        y2_max = y2_max.Y2;

        var svg = dimple.newSvg("#"+id, width, height);
        
        var chart = new dimple.chart(svg, data);
        chart.setBounds(60, 30, width-80, height-80);

		$.each(data, function(d) {
			if (data[d].DIM.substr(0, 3) != PACothers ) {
				chart.assignColor(data[d].DIM, colorself, "grey", 1);
			}
			else {
				chart.assignColor(data[d].DIM, colorothers, "grey", 1);
			}

			if (data[d].DIM.substr(0, 3) == PACoutlier ) {
				chart.assignColor(data[d].DIM, coloroutlier, "red", 1);
			}
		});

        var x = chart.addMeasureAxis("x", "X");
        x.tickFormat = ".1f";
        x.ticks = 10;
        if( !measures[1].qIsAutoFormat && measures[1].qNumFormat.qFmt.length > 0 )
        x.tickFormat = measures[1].qNumFormat.qFmt;

		var y = chart.addMeasureAxis("y", "Y");
        y.tickFormat = ".1f";
		y.ticks = 10;
        if( !measures[0].qIsAutoFormat && measures[0].qNumFormat.qFmt.length > 0 )
        y.tickFormat = measures[0].qNumFormat.qFmt;
        y.overrideMin = 0;
        y.overrideMax = Math.max(y_max, y2_max);
          
		var s = chart.addSeries(["DIM"], dimple.plot.bubble, [x, y]);
        
        var y2 = chart.addMeasureAxis("y", "Y2");
        y2.hidden = true;
        y2.tickFormat = y.tickFormat;
        y2.overrideMin = y.overrideMin;
        y2.overrideMax = y.overrideMax;
          
		var s2 = chart.addSeries(["DIM"], dimple.plot.line, [x, y2]);

		if( user_prop.transSwitch ) {
			x.title = measures[0].qFallbackTitle + " [R\xB2 = " + result.r2 + "] "+ "[" + result.string + "]";
		}
		else {
			x.title = measures[0].qFallbackTitle;
		}
		y.title = measures[1].qFallbackTitle;
        
        chart.draw();
        var filterValues = dimple.getUniqueValues(data, "DIM");  
        d3.selectAll("circle")
          .on("click", function(e) {
            /*var hide = false;
            var newFilterClick = [];
            filterValues.forEach(function(f) {
                if (f === e.aggField[0]){
                   hide = true;
                } else {
                   newFilterClick.push(f);
                }
            });*/
            var hello = newLinePlot(dimple, id, matrix, _, regression, user_prop, width, height, measures);
            /*if (hide) {
              d3.select("path").style("opacity", 0.1);
            } else {
              newFilterClick.push(e.aggField[0]);
              d3.select("path").style("opacity", 0.1);
            }
            filterValues = newFilterClick;*/
            // console.log('Data =>', hello);
            chart.data = dimple.filterData(hello, "DIM", filterValues);
            chart.draw(800);
        });        
        //////////////
      }
    }
  };
});

var newLinePlot = function(arg, fieldId, arg1, arg2, regression, arg3,  width, height, measures) {
     var data = arg1.map(function(d) {
             var DIM = d[0].qText;
             var X = d[1].qNum;
             var Y = d[2].qNum;
             if(isNaN(X)) X = 0;
             if(isNaN(Y)) Y = 0;
             return {
               "DIM": DIM,
               "X": (Math.random() * 0.2 + X),
               "Y": (Math.random() * 0.2 + Y)
             }
        });
        console.log('New => ', data);
        var temp_data = arg2.map(data, function(d) {
          return [d.X, d.Y];
        });
        var result = null;
        var regressiontype = arg3.regressionType;
		result = regression(regressiontype, temp_data, 1);
        arg2.each(data, function(elm, i) {
         elm.Y2 = result.points[i][1]; // [0]=x,[1]=ax+b
        });

        var y_max = arg2.max(data, function(d) { return d.Y; });
        y_max = y_max.Y;
        var y2_max = arg2.max(data, function(d) { return d.Y2; });
        y2_max = y2_max.Y2;
    
        var svg = arg.newSvg("#"+fieldId, width, height);
        
        var chart = new arg.chart(svg, data);
        chart.setBounds(60, 30, width-80, height-80);
        
        var x = chart.addMeasureAxis("x", "X");
        x.tickFormat = ".1f";
        x.ticks = 10;
        if( !measures[1].qIsAutoFormat && measures[1].qNumFormat.qFmt.length > 0 )
        x.tickFormat = measures[1].qNumFormat.qFmt;
    
        var y = chart.addMeasureAxis("y", "Y");
        y.tickFormat = ".1f";
		y.ticks = 10;
        if( !measures[0].qIsAutoFormat && measures[0].qNumFormat.qFmt.length > 0 )
        y.tickFormat = measures[0].qNumFormat.qFmt;
        y.overrideMin = 0;
        y.overrideMax = Math.max(y_max, y2_max);
  
        var y2 = chart.addMeasureAxis("y", "Y2");
        y2.hidden = true;
        y2.tickFormat = y.tickFormat;
        y2.overrideMin = y.overrideMin;
        y2.overrideMax = y.overrideMax;
          
		var s2 = chart.addSeries(["DIM"], arg.plot.line, [x, y2]);
    return data;
}