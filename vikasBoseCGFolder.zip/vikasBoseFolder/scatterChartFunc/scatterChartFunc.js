/**
* @Vikas Bose
*
* scatterChartFunc.JS - Common file for functions
* Create Date: 30/May/2018
**/

(function() {
 'use strict';
 
   var scatterChartFunc = {
      version: "0.0.1"
   };

/**Below code will itterate the data using jquery object `$`
          
# `colorOutlier` variable content the array value and it might be extended as per the requirement, if we differentiate
the color code.

# `assignColor` method: Associate a specific color with a passed string value. Setting this against a series value will
   cause any series using that value to color with the given fill and stroke. The only exception to this is where the 
   series is also under the influence of a color axis. 
   Syntax: dimple.chart.assignColor(tag, fill, stroke, opacity)
   tag (Required), fill (Required), stroke (Optional), opacity (Optional)
**/
   scatterChartFunc.colorCodeFun = function ($, data, chart, PACothers, colorself, colorothers, coloroutlier, outlierContent) {
       var a = $.each(data, function(d) {
          var colorOutlier = outlierContent;
          if (data[d].DIM.substr(0, 3) != PACothers) {
              chart.assignColor(data[d].DIM, colorself, "grey", 1);
          } else {
              chart.assignColor(data[d].DIM, colorothers, "grey", 1);
          }
          if (colorOutlier.indexOf(data[d].DIM.split("-")[1]) !== -1 && data[d].DIM.split("-")[1] !== "") {
             chart.assignColor(data[d].DIM, coloroutlier, "red", 1);
          }
      });
     return a;
   };
   scatterChartFunc.yMaxFun = function (_, data, axis) {
     return _.max(data, function(d) { return d[axis]; });
   };
/** Below code will create the title (calculation of Axis)
          
# svg is the object of dimple `newSvg` class, it also content the inbuild function/methods which create the dynamic DOM.

# we pass the `titleVal` into the text dom and create the dynamic text layer.
**/
   scatterChartFunc.topTitleFun = function (svg, user_prop, result, width) {
     var titleVal = (user_prop.transSwitch && result.r2) ? " [R\xB2 = " + (result.r2).toFixed(2) + "] "+ "[" + result.string + "]" : " [R\xB2 = No Result] [Y- No Result]";
     var displayTitle = svg.append("text")
            .attr("x", width-(titleVal.length+140))
            .attr("y", 40)
            .style("font-size", "9px")
            .style("font", "bold")
            .style("fill", "black")
            .text(titleVal);
     return displayTitle;
   };

if (typeof exports !== 'undefined') {
   module.exports = scatterChartFunc;
} else {
   window.scatterChartFunc = scatterChartFunc;
}

})();