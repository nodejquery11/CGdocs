/* 
# Benefits of JS
1. less server interaction
2. Immediate feedback or quick response 
3. increased interactivity
4. Rich interface

# Datatype
Number/ String/ Boolean/ Null/ Undefined

# Composit Datatype
Array/ Object

# Angular Js
webpack/ RxJS/ stackBlitz/ NativeScript/ JavaScript/ TypeScript
Angular CLI
$ ng new [create build new blue print of application]
$ ng generate component my-component
$ ng serve
$ ng build
$ ng-update @ angualr/core [to update the application]
$ ng add @ angular/pwa
$ Schematics
  $ router
  $ HTTP
  $ Forms [IMP]
  $ Animation
  $ i18n
$ protractor & Karma
$ language serivces
$ Angular Universl - server side rander
$ code Spliting [tree shaking]
$ Incrementality
$ matadata.json in Angualr
$ mataprograming
*/

// Print hello world
console.log("Hello World");
// document.write("Vikas Bose");

/*
# Difference between var/ let/ const in JavaScript
# Difference between context & Scope
  Every function invocation has both scope and context. Fundamentally scope is basically function-based and context is object-based.
  scope pretaint to the variable access of a function when it's invoke and it always unique.
  context always the value of `this`, which is reference of the current object and it is execute current code only.

*/


