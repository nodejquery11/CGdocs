define( ["qlik", "./d3.min", "./dimple.latest", "jquery", "./regression"],
function (qlik, d3, dimple, $, regression) {
    'use strict';
	return {
        definition : {
            type: "items",
            component: "accordion",
            items: {
                dimensions: {
                   uses: "dimensions",
                   min: 2
                },
                measures: {
                    uses: "measures",
                    min: 1
                },
                appearance: {
                    uses: "settings"
                } 
            }
        },
        initialProperties: {
            qHyperCubeDef: {
                qDimensions: [],
                qMeasures: [],
                qInitialDataFetch: [{
                    qWidth: 43,
                    qHeight: 100
                 }]
            }
        },
		support : {
			snapshot: true,
			export: true,
			exportData : true
		},
		paint: function ($element, layout) {
           var id = 'chartContainer';
           var width = $element.width();
           var height = $element.height();
           var qMatrix = layout.qHyperCube.qDataPages[0].qMatrix;

           if(document.getElementById(id)) {
              $("#"+id).empty();
           } else {
              $element.append($('<div />;').attr("id", "chartContainer").width(width).height(height));
           }
           
           // var finalData = [];
           var data = qMatrix.map(function(d) {
               var qText = d[0].qText;
               var X = (d[0].qNum === 'NaN') ? 0 : d[0].qNum;
               var Y = (d[1].qNum === 'NaN') ? 0 : d[1].qNum;               
               return {
                  "DIM": "X-"+qText,
                   "X": X,
                   "Y": Y
               }               
            });
            var avrage = data.map(function(d) { // Create an array of Y elements
               return d["Y"];
            });
            var meanValue = d3.mean(avrage);    // Calculate the avarage of Y element
            var yAxisSquare = data.map(function(d) {
                return Math.pow((d["Y"] - meanValue), 2);
            });
            var sumOfYAxisSquare = d3.sum(yAxisSquare);
            var sqrtOfYAxis = Math.sqrt(sumOfYAxisSquare/yAxisSquare.length);
            var aUpperPlot = data.map(function(d) {
                return {
                    "DIM":"A-UpperPlot-"+d["DIM"], 
                    "X":  d["X"],
                    "Y":  d["Y"]+ sqrtOfYAxis
                 };
            });
            var bLowerPlot = data.map(function(d) {
                return {
                    "DIM":"B-LowerPlot-"+d["DIM"], 
                    "X":  d["X"],
                    "Y":  d["Y"]- sqrtOfYAxis
                 };
            });
            
            var finalData = [data, aUpperPlot, bLowerPlot];
            var svg = dimple.newSvg("#chartContainer", width, height);
            var myChart = new dimple.chart(svg, finalData);
            
            myChart.setBounds(40, 20, width-80, height-80);
            var x = myChart.addMeasureAxis("x", "X");
            x.tickFormat = ".1f";
            x.ticks = 7.5;
            x.title = "X Axis";
            var y = myChart.addMeasureAxis("y", "Y");
            y.ticks = 7.5;            
            y.title = "Y Axis";
            
            $.each(finalData, function(i) {              
               $.each(finalData[i], function(d) {
                   if (finalData[i][d].DIM.substr(0, 1) === "X") {
                       //assignColor(object, targetColor, outlayColor, borderSize)
                        myChart.assignColor(finalData[i][d].DIM, "#ff704d", "#ff704d", 1);
                    } else if (finalData[i][d].DIM.substr(0, 1) === "A" ) {
                        myChart.assignColor(finalData[i][d].DIM, "#ccccb3", "#ccccb3", 1);
                    } else {
                        myChart.assignColor(finalData[i][d].DIM, "#fff", "#ffd11a", 1);
                    }
               });
            });
            //Normal X & Y bubble plot  
            var s1 = myChart.addSeries(["DIM"]);
            s1.data = finalData[0];
            s1.plot = dimple.plot.bubble;
            
            var s2 = myChart.addSeries(["DIM"]);
            s2.data = finalData[1];
            s2.plot = dimple.plot.bubble;
            
            var s3 = myChart.addSeries(["DIM"]);
            s3.data = finalData[2];
            s3.plot = dimple.plot.bubble;
            
            myChart.draw();
		}
	};

});

