const util = require('util');
var events = require('events');

var eventEmitter = new events.EventEmitter();
/*EventEmitter is the constructor

var eventTrigger = eventEmitter.on('clap', function(message) {
	  console.log("Clap :"+ message);
});

eventTrigger.emit('clap', 'hello vikas');
*/
/*We are creating the normal consructor using JS */
var person = function(name) {
	 this.name = name;
};

var vikas = new person('vikas bose');
var siva = new person('siva');
var karthik = new person('karthik');

util.inherits(person, events);
var peoples = [vikas, siva, karthik];

peoples.forEach(function(per){
	 per.on('clap', function(msg) {
	 	  console.log(per.name+': said '+msg);
	 });
});

vikas.emit('clap', 'Hello Vikas');
siva.emit('clap', 'Hello Siva');
karthik.emit('clap', 'Hello Karthik');

