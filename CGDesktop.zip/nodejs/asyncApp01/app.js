// app.js
var http = require('http');
var fs = require('fs');
var async = require('async');

console.log('vikas =>', async);
/*
Description: it will concate the function and run function one by one as per the sequance.
`concatSeries` is similar to concat()
*/
async.concat(['func01', 'func02', ...], fs.readdir, function(err, data) {
    
});
/*
Descrption: each is similar to the forEach function. It will effect entire array
*/
async.each(array_item, function(file, callback){
   ... statement
}, function(err) {
   .... statement
});
/*
Description: `forEachOf` function is similar like forEach, only the difference is it works on particular key/index
*/
async.forEachOf(array_item, function(value, key, callback) {
  ... statement
}, function(err) {
  .... statement
});
/*
Description: `every` is method when element call serial wise and if any this stop or make false then it will execute the main callback
*/
async.every(['file1','file2','file3'], function(filePath, callback) {
    fs.access(filePath, function(err) {
        callback(null, !err)
    });
}, function(err, result) {
    // if result is true then every file exists
});

/*
Description: `auto` is the method, which determine that best order of running async task. If any error ocurre in the running task then it will stop and execute the main callback
*/
async.auto({
    // this function will just be passed a callback
    readData: async.apply(fs.readFile, 'data.txt', 'utf-8'),
    showData: ['readData', function(results, cb) {
        // results.readData is the file's contents
        // ...
    }]
}, callback);
            