/**
Child Process:
Async methods - 
exec()
execFile()
spawn()
Sync methods - 
execSync()
execFileSync()
spawnSync()
*/
const childProcess = require('child_process');
var path = require('path');

var spawn = childProcess.spawn('ls', ['-h', '/usr']);
    spawn.stdout.on('data', (data) => {
      console.log(`stdout: ${data}`);
    });
    spawn.stderr.on('data', (data) => {
      console.log(`stderr: ${data}`);
    });
    spawn.on('close', (code) => {
      console.log(`child process exited with code ${code}`);
    });

/*
var ls = childProcess.exec('node', [] function(err, stdout, stderr) {
   console.log(`stdout: ${stdout}`);
   console.log(`stderr: ${stderr}`);  
});

ls.on('close', (code) => {
  console.log(`child process exited with code ${code}`);
});
*/
/*
ocean medallion
ocean.com
*/
