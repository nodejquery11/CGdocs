/* cluster functions
cluster is basically used for system and application based perfromance improvement methology. It is basically based on the core system processor. For example if you system is dual core or 8 core then cluster will give ability to Node Js to run their application in different core machine. SO instead of giving burdon into single process, it will distributed in multiple core machines.
In any case if first core machine get cresh then even your application will run perfectly as it will create the clone of your application in each core machine :).
How to cluster work?
It follows the two method for distributing the incoming connect
Round-robin approach - Here master process listen the port, accept the new connection and distributing the connection across the workers in round-robin fashion and avoid the overloading for workers.
Second approach, master process create the listen the socket and send it to the interested workers. then worker accept the directly connection.

Important functions:
cluster.fork(); [devide the core process into the workers]
cluster.on('exit', (worker, code, single) => { ...statement}); [event emited using the on keyword]


Note: Process.pid will always keep changing.

*/
const cluster = require('cluster');
const http = require('http');
const nubCPU = require('os').cpus().length;

if(cluster.isMaster) {
  console.log(`Master ${process.pid} is running`);
  
  /*loop the core and assign to the workers*/
  for(var i = 0; i < nubCPU; i++) {
    cluster.fork();
  }
  
  cluster.on('exit', (worker, code, single) => {
    console.log(`Worker ${worker}`);
    console.log(`Worker ${worker.process.id} died`);
  });  
  
} else {
  http.createServer((req, res) => {
    res.writeHead(200);
    res.end("hello world");
  }).listen(3000);
  console.log(`Worker ${process.pid} started`);
}


